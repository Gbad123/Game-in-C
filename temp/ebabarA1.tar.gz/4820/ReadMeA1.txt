Ebad Babar
0954164
Cis 4820 a1

To run the program:
  export DISPLAY=localhost:0
  make
  ./A1

Algorithum:
+---+---+---+
| 2 | 5 | 8 |
+---+---+---+
| 1 | 4 | 7 |  Z
+---+---+---+
| 0 | 3 | 6 |
+---+---+---+
      X

x = refers to the width
z = refers to the depth
y = refers to the height

Main:
    Create a yellow border around the world
    Set colour 10, light shade of gery similar to the one provided in the other Read me
  Build Rooms:
    Divides the world grid by 3 in both x and z to get zone 0
    Using xlen and zlen navigate to each sector to place one block in each sector
    The location for these blocks are stored in a global x and z array (corresponding w the room number)
  createRooms:
    Using the coordinates and max lengths calls buildWallX and buildWallZ
    buildWallX:
        double for loop making the walls along the x axis 5 units height
    buildWallZ:
        double for loop making the walls along the z axis 5 units height
    buildRoof:
        build the roof for the room
  findDoorLocation:
    loops through all the Rooms
    selects a random location along each wall
    Run through each room and decide how many doors it has
      Room 0 connects to 3 and 1 therefore build door along the Top and right
      doorT, doorR, doorB, doorL:
        uses the data it was provided to make a hole in the wall where the door should be
        made 5 in height to ensure its visible
  buildHalls:
    loops through until all rooms are connected
    following the same logic as door, calling top and right to see where halls need to be build
      Room zero connects to 3 on the right and 1 to the top
      to reduce compliction halls are only build along the top and right
        Meaning halls go 0 -> 3, 3 -> 6 and 0 -> 1, 1 -> 2
        not 3 -> 0, or 1 -> 0
    buildRight:
      Calculates the mid point and determins which direction the bend is
      Does the following twice: once above the door locaiton and once below
        calls buildHallX to make a hall from 0 towards 3
        calls buildHallX to make a halls from 3 towards 0
        calls buildHallZ to connect the 2 halls
    buildTop:
      Calculates the mid point and determins which direction the bend is
      Does the following twice: once to the right of the door locaiton and once to the left
        calls buildHallZ to make a hall from 0 towards 1
        calls buildHallZ to make a halls from 1 towards 0
        calls buildHallX to connect the 2 halls
    buildHallZ,buildHallX:
      2 for loops build the halls depending on the info it was given
      goes up 5 units to stay at the same level as the rooms
  randomBloxs:
    uses the max and min blocks globals to see how many blocks need to be placed
    randomly selects one of the Rooms
    selects a random location along the x axis and z axis to get the coordinates to place the bloc at
  createFloor:
    set colour at 9, uses the example one provided in the ReadMe
    uses colour 9 and 4 to create a prision like feel for the floor

Gravity:
  Called if fly mode is off
  Check current user location and see's if the spot below contains a bloc
  if not lower the user
  stop once reach the bloc or 25 (floor level)

collisionResponse:
  Uses getOldViewPosition and getViewPosition
  If current view position has a block
    Climb it if its only one unit high
    Set new position to old position
  Also ensure the player doesn't go out of bounce is x and z axis


Limitations and know issues:
  Floating point exception (core dumped)
    Might occur, was not able to replicate enough time to fix
  Halls
    The halls algorithum sometimes build inside the room
      Possible solution (work in progress) leave more min space between rooms
      Possible solution add a check in room to ensure no part of the halls is a room
    The halls sometimes bend earliers then expected, making them unpassable
  Clipping
    Tried to cover as much as I could
    Can be a little in the wall not pass the block tho